<?php
// config.php – konfiguracja globalna

define('SITE_NAME', 'Kamil Paprota');
define('PAGES_DIR',          __DIR__ . '/pages/');
define('PAGES_URL',          '/litecard-cms/pages/');          // <-- tutaj możesz zmienić na '/strony/', '/content/' itp.
define('ADMIN_TIMEOUT_MINUTES', 30);